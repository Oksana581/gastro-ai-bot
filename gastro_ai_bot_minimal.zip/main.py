from config import settings

if __name__ == "__main__":
    print("GOOGLE API KEY:", settings.GOOGLE_API_KEY)
    print("TELEGRAM TOKEN:", settings.TELEGRAM_BOT_TOKEN)
    print("CHANNEL ID:", settings.TELEGRAM_CHANNEL_ID)
    print("Websites to monitor:")
    for name, url in settings.WEBSITE_URLS.items():
        print(f"- {name}: {url}")
